// var mongoose = require('mongoose')
// var Schema = mongoose.Schema
//
// var rowSchema = new Schema({
//   position: Number,
//   teamName: String,
//   crestURI: String,
//   playedGames: String,
//   points: Number
// })
//
// var Row = mongoose.model( 'index', rowSchema )
//
// module.exports = Row
